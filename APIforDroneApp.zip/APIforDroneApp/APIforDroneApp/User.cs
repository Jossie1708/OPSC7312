﻿namespace APIforDroneApp
{
    using Microsoft.AspNetCore.Authorization.Infrastructure;
    using Microsoft.Data.SqlClient;

    namespace DroneAPI
    {


        public class User
        {

            public string username { get; set; }
            public string email { get; set; }
            public string password { get; set; }
            public string fingerprintID { get; set; }

            public User(string email)
            {
                this.email = email;
                LoadUserInfoFromDatabase();
            }

            private void LoadUserInfoFromDatabase()
            {
                // Connection string should be stored securely, e.g., in configuration files
                string connectionString = "Server=tcp:frogtrackserver.database.windows.net,1433;Initial Catalog=DroneInformation_POE;Persist Security Info=False;User ID=Duncan;Password=Ilovehockey88;" +
                                          "MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT Username, Password, FingerprintID FROM UserDetails WHERE Email = @Email";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Email", this.email);

                        try
                        {
                            connection.Open();
                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    this.username = reader["Username"].ToString();
                                    this.password = reader["Password"].ToString();
                                    this.fingerprintID = reader["FingerprintID"] != DBNull.Value ? reader["FingerprintID"].ToString() : null;
                                }
                                else
                                {
                                    // Handle the case where the user is not found
                                    throw new Exception("User not found.");
                                }
                            }
                        }
                        catch (SqlException ex)
                        {
                            // Handle exceptions (e.g., log them)
                            Console.WriteLine("An error occurred while loading user information: " + ex.Message);
                            throw; // Rethrow the exception after logging
                        }
                    }
                }
            }

            // new users 
            public User(string username, string email, string password)
            {
                this.username = username;
                this.email = email;
                this.password = password;
                this.fingerprintID = "null";

            }

            public bool updatePassword(string oldPass, string newPass)
            {
                bool success = false;

                // Connection string should be stored securely, e.g., in configuration files
                string connectionString = "Server=tcp:frogtrackserver.database.windows.net,1433;Initial Catalog=DroneInformation_POE;Persist Security Info=False;User ID=Duncan;Password=Ilovehockey88;" +
                                          "MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // First, check if the old password matches
                    string checkQuery = "SELECT COUNT(*) FROM UserDetails WHERE Email = @Email AND Password = @OldPassword";

                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        // Set parameter values
                        checkCommand.Parameters.AddWithValue("@Email", this.email);
                        checkCommand.Parameters.AddWithValue("@OldPassword", oldPass);

                        try
                        {
                            connection.Open();
                            int count = (int)checkCommand.ExecuteScalar();

                            if (count > 0) // Old password matches
                            {
                                // Now update the password
                                string updateQuery = "UPDATE UserDetails SET Password = @NewPassword WHERE Email = @Email";

                                using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                                {
                                    // Set parameter values
                                    updateCommand.Parameters.AddWithValue("@NewPassword", newPass);
                                    updateCommand.Parameters.AddWithValue("@Email", this.email);

                                    updateCommand.ExecuteNonQuery();
                                    success = true; // Password updated successfully
                                }
                            }
                        }
                        catch (SqlException ex)
                        {
                            success = false; // Handle exceptions as needed
                            Console.WriteLine("An error occurred while updating the password: " + ex.Message);
                        }
                    }
                }

                return success;
            }



            //implemented in part 3 of the project
            public void updateFingetprintID()
            {
            }

            public void AddFingerprintID()
            {

            }

            public bool updateUsername(string newUsername)
            {
                this.username = newUsername;
                bool success = false;

                // Connection string should be stored securely, e.g., in configuration files
                string connectionString = "Server=tcp:frogtrackserver.database.windows.net,1433;Initial Catalog=DroneInformation_POE;Persist Security Info=False;User ID=Duncan;Password=Ilovehockey88;" +
                                          "MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "UPDATE UserDetails SET Username = @Username WHERE Email = @Email";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Set parameter values
                        command.Parameters.AddWithValue("@Username", this.username);
                        command.Parameters.AddWithValue("@Email", this.email);

                        try
                        {
                            connection.Open();
                            command.ExecuteNonQuery();
                            success = true;
                        }
                        catch (SqlException ex)
                        {
                            success = false; // Handle exceptions as needed

                        }


                    }
                }

                return success;
            }
         

            public bool validUser(string email, string password)
            {
                bool isValid = false;

                // Connection string should be stored securely, e.g., in configuration files
                string connectionString = "Server=tcp:frogtrackserver.database.windows.net,1433;Initial Catalog=DroneInformation_POE;Persist Security Info=False;User ID=Duncan;Password=Ilovehockey88;" +
                                          "MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT COUNT(*) FROM UserDetails WHERE Email = @Email AND Password = @Password";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Set parameter values
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@Password", password);

                        try
                        {
                            connection.Open();
                            int count = (int)command.ExecuteScalar();

                            isValid = count > 0; // If count is greater than 0, the user exists
                        }
                        catch (SqlException ex)
                        {
                            Console.WriteLine("An error occurred while validating user: " + ex.Message);
                         
                        }
                    }
                }

                return isValid;
            }


            public string AddUserToDatabase()
            {
                string success = "false";
                // Connection string should be stored securely, e.g., in configuration files
                string connectionString = "Server=tcp:frogtrackserver.database.windows.net,1433;Initial Catalog=DroneInformation_POE;Persist Security Info=False;User ID=Duncan;Password=Ilovehockey88;" +
                                          "MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";



                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO UserDetails (Username, Email, Password, FingerprintID) VALUES (@Username, @Email, @Password, @FingerprintID)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Set parameter values
                        command.Parameters.AddWithValue("@Username", this.username);
                        command.Parameters.AddWithValue("@Email", this.email);
                        command.Parameters.AddWithValue("@Password", this.password);
                        // Convert fingerprintID to byte array if necessary
                        if (this.fingerprintID != null)
                        {
                            byte[] fingerprintBytes = Convert.FromBase64String(this.fingerprintID); // Assuming you store it as a Base64 string
                            command.Parameters.AddWithValue("@FingerprintID", fingerprintBytes);
                        }
                        else
                        {
                            command.Parameters.AddWithValue("@FingerprintID", DBNull.Value);
                        }

                        try
                        {
                            connection.Open();
                            command.ExecuteNonQuery();
                            success = "true";
                        }
                        catch (SqlException ex)
                        {
                            success = 
                            "An error occurred while updating the password: " + ex.Message;
                        }
                    }
                }

                return success;
            }

        }
    }
}