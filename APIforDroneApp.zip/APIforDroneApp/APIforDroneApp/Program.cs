
using APIforDroneApp.DroneAPI;

namespace APIforDroneApp
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddAuthorization();

            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

       
                app.UseSwagger();
                app.UseSwaggerUI();
            

            app.UseHttpsRedirection();

            app.UseAuthorization();

            // POST to add a new user
            app.MapPost("/addUser", (string username, string email, string password) =>
            {
                try
                {
                    User newUser = new User(username, email, password);
                    string success = newUser.AddUserToDatabase();
                    return Results.Ok(success); // Return 200 OK with success status
                }
                catch
                {
                    return Results.StatusCode(StatusCodes.Status500InternalServerError); // Return 500 Internal Server Error
                }
            })
            .WithName("addUser")
            .WithOpenApi();

            // PUT to update username
            app.MapPut("/updateUsername", (string email, string newUsername) =>
            {
                try
                {
                    User currentUser = new User(email);
                    bool success = currentUser.updateUsername(newUsername);
                    return Results.Ok(success); // Return 200 OK with success status
                }
                catch
                {
                    return Results.StatusCode(StatusCodes.Status500InternalServerError); // Return 500 Internal Server Error
                }
            })
            .WithName("updateUsername")
            .WithOpenApi();

            // PUT to update password
            app.MapPut("/updatePassword", (string email, string oldPass, string newPass) =>
            {
                try
                {
                    User currentUser = new User(email);
                    bool success = currentUser.updatePassword(oldPass, newPass);
                    return Results.Ok(success); // Return 200 OK with success status
                }
                catch
                {
                    return Results.StatusCode(StatusCodes.Status500InternalServerError); // Return 500 Internal Server Error
                }
            })
            .WithName("updatePassword")
            .WithOpenApi();

            // GET to retrieve the username
            app.MapGet("/getUsername", (string email) =>
            {
                try
                {
                    User currentUser = new User(email);
                    string username = currentUser.username;
                    return Results.Ok(username); // Return 200 OK with the username
                }
                catch
                {
                    return Results.StatusCode(StatusCodes.Status500InternalServerError); // Return 500 Internal Server Error
                }
            })
            .WithName("getUsername")
            .WithOpenApi();

            // GET to retrieve the username
            app.MapGet("/validateUser", (string email, string password) =>
            {
                try
                {
                    User currentUser = new User(email);
                    bool valid = currentUser.validUser(email, password);
                    return Results.Ok(valid); // Return 200 OK with the username
                }
                catch
                {
                    return Results.StatusCode(StatusCodes.Status500InternalServerError); // Return 500 Internal Server Error
                }
            })
            .WithName("validateUser")
            .WithOpenApi();



            app.Run();
        }
    }
}
